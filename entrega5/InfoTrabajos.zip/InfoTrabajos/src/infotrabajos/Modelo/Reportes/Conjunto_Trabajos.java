/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package infotrabajos.Modelo.Reportes;

import java.util.ArrayList;

/**
 *
 * @author david
 */
public class Conjunto_Trabajos {
    private static ArrayList<Trabajo> Trabajos = new ArrayList<Trabajo>();

    public static ArrayList<Trabajo> getTrabajos() {
        return Trabajos;
    }

    public static void setTrabajos(ArrayList<Trabajo> Trabajos) {
        Conjunto_Trabajos.Trabajos = Trabajos;
    }
    public static void agregar_trabajo(Trabajo T){
        Trabajos.add(T);
    }
    public static void ordenar_trabajos(){
        Trabajos.sort(null);
    }
}
