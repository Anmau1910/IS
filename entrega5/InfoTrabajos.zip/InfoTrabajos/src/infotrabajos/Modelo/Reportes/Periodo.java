/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package infotrabajos.Modelo.Reportes;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author david
 */
public class Periodo {
    private static Date Inicio;
    private static Date Fin; 
    private static Date minimo;
    private static Date maximo;

    private Periodo(){                            
        DateFormat sourceFormat = new SimpleDateFormat("dd/MM/yyyy");
        try {
            minimo = sourceFormat.parse("01/01/2014");
        } catch (ParseException ex) {}
        maximo = new Date();
    }
    private static void setMaximoyMinimo(){                
        DateFormat sourceFormat = new SimpleDateFormat("dd/MM/yyyy");
        try {
            minimo = sourceFormat.parse("01/01/2014");
        } catch (ParseException ex) {}
        maximo = new Date();
        
    }
    public static Date getInicio() {
        return Inicio;
    }

    public static void setInicio(Date Ini) {
        setMaximoyMinimo();
        if(Ini != null && Ini.compareTo(minimo) >= 0)
            Inicio = Ini;
        else
            Inicio = minimo;
    }
    
    public static Date getFin() {
        return Fin;
    }

    public static void setFin(Date Final) {
        setMaximoyMinimo();
        if(Final != null && Final.compareTo(maximo) < 0)
            Fin = Final;
        else
            Fin = maximo;
    }
    
}
