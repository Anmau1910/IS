/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package infotrabajos.Modelo.Reportes;

/**
 *
 * @author david
 */
public class PeriodoSingleton {
    
    private PeriodoSingleton() {
    }
    
    public static PeriodoSingleton getInstance() {
        return PeriodoSingletonHolder.INSTANCE;
    }
    
    private static class PeriodoSingletonHolder {

        private static final PeriodoSingleton INSTANCE = new PeriodoSingleton();
    }
}
