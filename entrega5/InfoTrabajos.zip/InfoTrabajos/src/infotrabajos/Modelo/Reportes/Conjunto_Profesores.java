/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package infotrabajos.Modelo.Reportes;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author david
 */
public class Conjunto_Profesores {
    private static ArrayList<Profesor> Profesores = new ArrayList<Profesor>();

    public static ArrayList<Profesor> getProfesores() {
        return Profesores;
    }

    public static void setProfesores(ArrayList<Profesor> Profesores) {
        Conjunto_Profesores.Profesores = Profesores;
    }

    public static void agregar_profesor(Profesor p){
        Profesores.add(p);
    }
    public static void ordenar_profesores(){
        Profesores.sort(null);
    }
    public static Profesor obtener_profesor(int ci){
        for(Iterator<Profesor> i = Profesores.iterator();i.hasNext(); ){
            Profesor p = i.next();
            if(p.getCedula() == ci ){
                return p;
            }
        }
        return null;
        
    }
    public static Profesor obtener_profesor(String Nombre,String Apellido){
        for(Iterator<Profesor> i = Profesores.iterator();i.hasNext(); ){
            Profesor p = i.next();
            if(p.getNombre() == Nombre && p.getApellido() == Apellido ){
                return p;
            }
        }
        return null;
        
    }
}
