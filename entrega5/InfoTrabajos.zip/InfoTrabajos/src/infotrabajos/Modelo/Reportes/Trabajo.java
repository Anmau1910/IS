/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package infotrabajos.Modelo.Reportes;

import java.util.Date;

/**
 *
 * @author david
 */
public class Trabajo {
    String Titulo;
    Date Fecha;
    String grado;
    Estudiante Autor1;
    Estudiante Autor2;
    Profesor Tutor1;
    Profesor Tutor2;

    public Trabajo(String Titulo, Date Fecha, String grado, Estudiante Autor1, Estudiante Autor2, Profesor Tutor1, Profesor Tutor2) {
        this.Titulo = Titulo;
        this.Fecha = Fecha;
        this.grado = grado;
        this.Autor1 = Autor1;
        this.Autor2 = Autor2;
        this.Tutor1 = Tutor1;
        this.Tutor2 = Tutor2;
    }

    public String getTitulo() {
        return Titulo;
    }

    public void setTitulo(String Titulo) {
        this.Titulo = Titulo;
    }

    public Date getFecha() {
        return Fecha;
    }

    public void setFecha(Date fecha) {
        this.Fecha = fecha;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

    public Estudiante getAutor1() {
        return Autor1;
    }

    public void setAutor1(Estudiante Autor1) {
        this.Autor1 = Autor1;
    }

    public Estudiante getAutor2() {
        return Autor2;
    }

    public void setAutor2(Estudiante Autor2) {
        this.Autor2 = Autor2;
    }

    public Profesor getTutor1() {
        return Tutor1;
    }

    public void setTutor1(Profesor Tutor1) {
        this.Tutor1 = Tutor1;
    }

    public Profesor getTutor2() {
        return Tutor2;
    }

    public void setTutor2(Profesor Tutor2) {
        this.Tutor2 = Tutor2;
    }
    
}
