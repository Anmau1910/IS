/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package infotrabajos.Controlador;

import java.util.Scanner;

/**
 *
 * @author david
 */
public class Ctrl_Acceso {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        infotrabajos.Vista.Admin.IInfoTrabajos i;
        i = new infotrabajos.Vista.Admin.IInfoTrabajos();
        i.setDefaultCloseOperation(i.EXIT_ON_CLOSE);
        i.setVisible(true);
    }
    
}
