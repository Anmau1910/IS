/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package infotrabajos.Controlador;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author david
 */
public class Ctrl_Comite {
    void cargar_trabajos() throws FileNotFoundException{
        File trabajos = new File("trabajos.txt");
        Scanner scanner_trabajos = new Scanner(trabajos);
        boolean eof = scanner_trabajos.hasNextLine();
        if(eof == true){
            //desplegar("el documento esta vacio");
        }
        boolean formValido = true;
        while(formValido == true && eof == false){
            scanner_trabajos.useDelimiter(";");
            String trabajo = scanner_trabajos.next();
            formValido = validar_formato(trabajo);
            if(formValido == false){
                //desplegar("formato invalido");
                
            }
        }
        
    }
    boolean validar_formato(String trabajo){
        Scanner s = new Scanner(trabajo);
        s.useDelimiter("#");
        String nivel = s.next();
        if(nivel != "TEG" && nivel != "TGM" && nivel != "TDR"){
            return false;
        }
        String Titulo = s.next();
        if(Titulo.isEmpty()){
            return false;
        }
        try{
        int ci = Integer.parseInt(s.next());
        String Apellido1 = s.next().substring(1);
        String Nombre1 = s.next();
        String ci_2 = s.next().substring(2);
        String Apellido2 = s.next();
        String Nombre2 = s.next();
        String sem1 = s.next().substring(1);
        int year = Integer.parseInt(sem1.substring(sem1.indexOf('-')));
        if(sem1.contains("II")){
            sem1 = "II";
        }else if(sem1.contains("I")){
            sem1 = "I";
        }else{
            return false;
        }
        if(year > 2018)
            return false;
        String fechaString = s.next();
        Scanner se = new Scanner(fechaString);
        se.useDelimiter("/");
        int dd = Integer.parseInt(se.next());
        int mm = Integer.parseInt(se.next());
        int aa = Integer.parseInt(se.next());
        Date fecha = new Date();
        if(mm > 12 || mm < 1 || dd > 31 || dd < 1 || aa < 2014 || aa > 2018)
            return false;
        String ci_s = s.next();
        int ci_t = Integer.parseInt(ci_s.substring(0,ci_s.length()-1));
        //todo lo demas es opcional
        }catch(NumberFormatException e){
            return false;
        }
        
        
        return true;
    }
    
    
}
