/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package infotrabajos.Controlador;

import infotrabajos.Modelo.Reportes.Conjunto_Profesores;
import infotrabajos.Modelo.Reportes.Conjunto_Trabajos;
import java.io.File;
import infotrabajos.Modelo.Reportes.Estudiante;
import infotrabajos.Modelo.Reportes.Profesor;
import infotrabajos.Modelo.Reportes.Trabajo;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author david
 */
public class Ctrl_Comite {
    
    public void desplegar(String mensaje){
           JOptionPane.showMessageDialog(null, mensaje);
    }
    
    public void cargar_profesores() throws FileNotFoundException{
        File profesores = new File("profs_Centros.txt");
        Scanner scanner_profesores = new Scanner(profesores);
        scanner_profesores.useDelimiter(";");
        boolean eof = !scanner_profesores.hasNext();
        if(eof == true){
            desplegar("el documento esta vacio");
        }
        while(scanner_profesores.hasNext()){
            String profesor = scanner_profesores.next();
            Scanner s = new Scanner(profesor);
            s.useDelimiter("#");
            String cedula = s.next();
            cedula = cedula.replaceAll("\\s+","");
            int ci = Integer.parseInt(cedula);
            String Apellido = s.next();
            String Nombre = s.next();
            String Centro = s.next();
            Profesor p = new Profesor(Nombre,Apellido,Centro,ci);
            Conjunto_Profesores.agregar_profesor(p);
        }
    }
    
    public void cargar_trabajos() throws FileNotFoundException{
        File trabajos = new File("trabajos.txt");
        Scanner scanner_trabajos = new Scanner(new BufferedReader(new FileReader(trabajos)));;
        boolean tu = scanner_trabajos.hasNextByte();
        tu = scanner_trabajos.hasNext();
        tu = scanner_trabajos.hasNextLine();
        scanner_trabajos.useDelimiter(";");
        boolean eof = !scanner_trabajos.hasNext();
        if(eof == true){
            desplegar("el documento esta vacio");
            return;
        }
        boolean formValido = true;
        while(formValido == true && scanner_trabajos.hasNext()){
            String trabajo = scanner_trabajos.next().toString();
            
            try{
            formValido = validar_formato(trabajo);
            }catch(Exception ex){
                desplegar("error: " +ex.getMessage());
                desplegar("error2: " +ex.toString());
            }
            if(formValido == false){
                desplegar("formato invalido");
            }
        }
        
        
    }
    public boolean validar_formato(String trabajo){
        Scanner s = new Scanner(trabajo);
        s.useDelimiter("#");
        String grado = s.next();
        if(grado.contains("TEG"))
            grado = "TEG";
        else if(grado.contains("TGM"))
            grado = "TGM";
        else if(grado.contains("TDR"))
            grado = "TDR";
        else
            return false;
        String Titulo = s.next();
        if(Titulo.isEmpty()){
            return false;
        }
        int ci = Integer.parseInt(s.next());
        String Apellido1 = s.next();
        String Nombre1 = s.next();
        int ci_2 = -1;
        try{
        ci_2 = Integer.parseInt(s.next());
        }catch(NumberFormatException e){
            ci_2 = -1;
        }
        String Apellido2 = s.next();
        String Nombre2 = s.next();
        String sem1 = s.next();
        int year = Integer.parseInt(sem1.substring(sem1.indexOf('-')));
        if(sem1.contains("II")){
            sem1 = "II";
        }else if(sem1.contains("I")){
            sem1 = "I";
        }else{
            return false;
        }
        if(year > 2018)
            return false;
        String fechaString = s.next();
        Scanner se = new Scanner(fechaString);
        se.useDelimiter("/");
        int dd = Integer.parseInt(se.next());
        int mm = Integer.parseInt(se.next());
        int aa = Integer.parseInt(se.next());
        if(mm > 12 || mm < 1 || dd > 31 || dd < 1 || aa < 2014 || aa > 2018)
            return false;
        DateFormat sourceFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date fecha;
        try {
            fecha = sourceFormat.parse(fechaString);
        } catch (ParseException ex) {
            return false;
        }
        int ci_t = Integer.parseInt(s.next());
        String Apellido_t1 = s.next();
        String Nombre_t1 = s.next();
        int ci_t2 = -1;
        try{
        ci_t2 = Integer.parseInt(s.next());
        }catch(NumberFormatException e){
            ci_t2 = -1;
        }
        String Apellido_t2 = s.next();
        String Nombre_t2 = s.next();
        
        Estudiante Autor1;
        Estudiante Autor2;
        Profesor Tutor1;
        Profesor Tutor2;
        
        if(Nombre1.isEmpty() && Nombre2.isEmpty())
            Autor1 = new Estudiante(ci);
        else
            Autor1 = new Estudiante(Nombre1,Apellido1,ci);
        
        if(ci_2 != -1){
            Autor2 = new Estudiante(Nombre2,Apellido2,ci_2);
        }else
            Autor2 = null;
        if(Apellido_t1.isEmpty() && Nombre_t1.isEmpty())
            Tutor1 = Conjunto_Profesores.obtener_profesor(ci_t);
         else    
            Tutor1 = new Profesor(Nombre_t1,Apellido_t1,ci_t);
        if(ci_t2 != -1){
            if(Apellido_t2.isEmpty() && Nombre_t2.isEmpty())
                Tutor2 = Conjunto_Profesores.obtener_profesor(ci_t2);
            else    
                Tutor2 = new Profesor(Nombre_t2,Apellido_t2,ci_t2);
        
        }else
            Tutor2 = null;
        Trabajo T;
        T = new Trabajo(Titulo,fecha,grado,Autor1,Autor2,Tutor1,Tutor2);
        Conjunto_Trabajos.agregar_trabajo(T);
        
        
        return true;
    }
    
    
}
